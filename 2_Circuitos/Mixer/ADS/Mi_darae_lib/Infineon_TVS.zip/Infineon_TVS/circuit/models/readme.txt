ADS file ext:       .net
Spice file ext:     .lib
Spectre model ext:  .scs
H-Spice modelext:   .hsp
APLAC model ext:    .i
